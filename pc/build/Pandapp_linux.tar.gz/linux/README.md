****Welcome on Pandapp****

*Step 1 :*

>Install packages :
>>'Anaconda3' for create virtual environment (https://docs.anaconda.com/anaconda/install/linux/) <br />
 'xdotool' for lock screen and use move row <br />
 'playerctl' for control music

*Step 2 :*
> execute 'make setup'

*Step 3 :*
> execute 'make run'

*Step 4 :*
> Enjoy !! **; D**
