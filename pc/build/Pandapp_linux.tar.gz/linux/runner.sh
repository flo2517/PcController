#!/bin/bash

source activate Pandapp_venv
python3.8 Pandapp.py
conda deactivate